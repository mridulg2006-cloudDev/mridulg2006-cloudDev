# Premium GitHub Profile Setup

## 1. Create the profile repository

Create a **public** repository whose name exactly matches your GitHub username. Put this package's `README.md`, `assets/` folder and `.github/` folder in that repository.

## 2. Replace the username placeholder

In `README.md`, replace every occurrence of:

```text
YOUR_GITHUB_USERNAME
```

with your actual GitHub username.

## 3. Recommended repository naming map

Use the numbering consistently:

```text
1-WeatherLens
2-DweLLIQ
3-QueueLess
4-PassGen
5-HexaCALM
6-Coding-360
7-AutoRev-1.0
8-AutoRev-2.0
9-ApexWall
10-Pit-Wall-360
11-PitWall-360-NewGen
12-The-Pit-Wall-360
```

The pattern is:

```text
Project Number - Project Name - Version when applicable
```

Do not interpret `360` or `NewGen` as repository numbers; they remain part of the project name. `1.0` and `2.0` remain AutoRev version identifiers.

## 4. Run the contribution animation

1. Push `.github/workflows/snake.yml` to the default branch.
2. Open the profile repository on GitHub.
3. Open **Actions**.
4. Choose **Generate Contribution Snake**.
5. Select **Run workflow**.
6. Wait for the `output` branch to appear.
7. Reload the profile.

## 5. Private repository strategy

The profile README is public, so every project name and description written in it becomes public even when the source repository remains private.

For recruiter access, use one of these approaches for the strongest projects:

- Publish a carefully cleaned source repository.
- Publish a separate public case-study repository containing architecture, screenshots, feature explanations and selected non-sensitive code.
- Add a live demo link while keeping the main source private.

A strong public trio would be:

```text
1-WeatherLens
4-PassGen
6-Coding-360
```

You can keep DweLLIQ, HexaCALM and AutoRev private while publishing polished case studies for them.

## 6. Recommended profile settings

- Enable private contribution counts if you want the graph to show activity without exposing repository details.
- Use a short profile bio such as:

```text
Full-stack developer building AI products, secure platforms and real-time web experiences.
```

- Use a professional profile photo or a consistent developer mark.
- Keep only the strongest public repositories pinned.

## 7. Theme identity

This package uses the **Nexus Systems** theme:

```text
Base: Obsidian / midnight glass
Primary signal: Electric cyan
Secondary signal: Ultraviolet
Highlight: Neon magenta
Visual language: System console, orbiting stack, scan lines and signal pulses
```

It is intentionally separate from the Formula racing identity used inside the Pit Wall and ApexWall projects. Your profile represents you as a complete frontend + backend engineer; individual repositories can keep their own product themes.
